package com.example.projeto_tarefas_save_memory

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
